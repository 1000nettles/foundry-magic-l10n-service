class Localize {

  /*getResponse: () => {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
      body: '<p>Hello world! I am the start of the FoundryVTT Magic L18n function.</p>',
    };
  }*/

  execute(event) {
    console.log(event);
    console.log(event.body);

    if (!event?.body) {
      return this.successResponse();
    }

    /*try {
      const body = JSON.parse(event.body);
    } catch (e) {
      console.log(e);
      return this.successResponse();
    }*/

    const { body } = event;

    console.log(typeof body);

    if (!body || !body?.manifest_url) {
      console.log('No manifest URL defined');
      return this.successResponse();
    }

    console.log(body.manifest_url);
  }

  successResponse() {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
      body: '<p>Hello world! I am the start of the FoundryVTT Magic L18n function.</p>',
    };
  }

}

module.exports = Localize;
