class Localize {

  /*getResponse: () => {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
      body: '<p>Hello world! I am the start of the FoundryVTT Magic L18n function.</p>',
    };
  }*/

  execute(event) {
    console.log(event);
    console.log(event.body);

    if (!event?.body) {
      return this.successResponse();
    }

    const { body } = event;

    if (!body || !body?.manifest_url) {
      return this.successResponse();
    }

    console.log(body.manifest.url);
  }

  successResponse() {
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
      body: '<p>Hello world! I am the start of the FoundryVTT Magic L18n function.</p>',
    };
  }

}

module.exports = Localize;
