const main = require('./main');

main.handler({ body: 'a_body' }, null, () => {});