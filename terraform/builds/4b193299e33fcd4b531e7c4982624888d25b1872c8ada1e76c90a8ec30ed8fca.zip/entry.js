const main = require('./main');

main.handler(null, null, () => {});