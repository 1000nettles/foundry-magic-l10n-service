'use strict'

import localize from './localize';

exports.handler = function (event, context, callback) {
  const response = localize.getResponse();
  callback(null, response)
}
